// Exercicio004.C, João Victor Terra Pereira, imprimir o texto solicitado com printf, 06/03/2024

#include <stdio.h>

int main() {
  printf("\"cinco\" (José Lino Grünewald, 1987)\n\n1\n\n2 2\n\n3 3 3\n\n4 4 4 4\n\nc i n c o\n");
  return 0;
}