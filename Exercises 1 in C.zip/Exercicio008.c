// Exercicio008.C, João Victor Terra Pereira, imprimir o texto solicitado com printf, 04/03/2024

# include <stdio.h>

int main()
{
  printf("   __o\n");
  printf(" _ \\<_\n");
  printf("(_)/(_)\n");

  return 0;
}