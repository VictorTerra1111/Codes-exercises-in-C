// Exercicio009.C, João Victor Terra Pereira, imprimir o desenho solicitado com printf, 04/03/2024

#include <stdio.h>

int main()
{
  printf("  .-\"-.\n");
  printf(" /|6 6|\\\n");
  printf("{/(_O_)\\}\n");
  printf(" _/ ˆ \\_\n");
  printf("(/_/ˆ\\_\\)\n");
  return 0;
}