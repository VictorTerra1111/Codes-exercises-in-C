// Exercicio006.C, João Victor Terra Pereira, imprimir o desenho solicitado com printf, 04/03/2024

# include <stdio.h>

int main()
{
  printf(" ___   _   _    ___   ___   ___\n");
  printf("| _ \\ | | | |  / __| | _ \\ / __|\n");
  printf("|  _/ | |_| | | (__  |   / \\__ \\\n");
  printf("|_|    \\___/   \\___| |_|_\\ |___/\n");
  return 0;
}