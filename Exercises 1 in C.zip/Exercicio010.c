// Exercicio010.C, João Victor Terra Pereira, imprimir o desenho solicitado com printf, 04/03/2024

# include <stdio.h>

int main()
  {
  printf("+---------------------------------------------+\n");
  printf("| Só pelo amor o homem se realiza plenamente. |\n");
  printf("|                                      Platão |\n");
  printf("+---------------------------------------------+\n");
  return(0);
  }