// Exercicio005.C, João Victor Terra Pereira, imprimir o texto solicitado com printf, 06/03/2024

#include <stdio.h>

int main()
{
  printf("\"Poeminho do Contra\" (Mário Quintana)\n\nTodos esses que aí estão\nAtravancando meu caminho,\nEles passarão...\nEu passarinho!\n");
  return 0;
}