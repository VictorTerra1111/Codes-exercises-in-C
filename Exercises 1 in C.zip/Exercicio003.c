// Exercicio003.C, João Victor Terra Pereira, imprimir o texto solicitado com printf, 04/03/2024

#include <stdio.h>

int main()
{
  printf("\"Velocidade\" (Ronaldo Azeredo, 1957)\n");
  printf("\n");
  printf("VVVVVVVVVV\n");
  printf("VVVVVVVVVE\n");
  printf("VVVVVVVVEL\n");
  printf("VVVVVVVELO\n");
  printf("VVVVVVELOC\n");
  printf("VVVVVELOCI\n");
  printf("VVVVELOCID\n");
  printf("VVVELOCIDA\n");
  printf("VVELOCIDAD\n");
  printf("VELOCIDADE\n");
return 0;
}