// Exercicio002.C, João Victor Terra Pereira, imprimir o poema solicitado com printf, 04/03/2024

#include <stdio.h>

int main()
{
  printf("Olha,\n");
  printf("Entre um pingo e outro\n");
  printf("A chuva não molha.\n");
  printf("\n");
  printf("Millôr Fernandes (\"Hai-kais\", 1968)\n");
return 0;
}
