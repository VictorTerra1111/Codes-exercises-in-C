// Exercicio001.C, João Victor Terra Pereira, imprimir o texto solicitado com printf, 04/03/2024

#include <stdio.h>

int main()
{
  printf("\"A dúvida é o princípio da sabedoria.\" (Aristóteles)\n");
  return 0;
}