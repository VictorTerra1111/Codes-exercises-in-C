// Exercicio057.C, João Victor Terra Pereira, imprimir o desenho solicitado com printf, 04/03/2024

# include <stdio.h>

int main()
{
    printf(" ____            __ ____        __        __\n");
    printf("/\\ _ `\\         / //\\ _ `\\     /\\ \\      /\\ \\\n");
    printf("\\ \\ \\/\\_\\      / / \\ \\ \\/\\_\\   \\_\\ \\___  \\_\\ \\___\n");
    printf(" \\ \\ \\/_/_    / /   \\ \\ \\/_/_ /\\___  __\\/\\___  __\\\n");
    printf("  \\ \\ \\L\\ \\  / /     \\ \\ \\L\\ \\\\/__/\\ \\_/\\/__/\\ \\_/\n");
    printf("   \\ \\____/ /_/       \\ \\____/    \\ \\_\\     \\ \\_\\\n");
    printf("    \\/___/ /_/         \\/___/      \\/_/      \\/_/\n");
    return(0);
}