#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#define MAX_BOLAS 15
#define FLAG 0
#define VAZIA 0
#define CHEIA 1
#define MAX 10

typedef int qnt;
typedef struct { // estrutura com o registro de cada jogador incluindo nome e numero de rodadas
    char nome[40];
    int rodadas;
} player; //chamada de player

 /* =============================
Autor: Joao Victor Terra Pereira
Data: 30/06/2024
Nome: Speculate v5.0
Explicao: este codigo transporta o jogo de tabuleiro fisico Speculate para o digital com um algoritmo que interage com o usuario atraves do terminal de C. 
Regrad do jogo: 
      Speculate eh um jogo para dois ou mais jogadores que utiliza 33 bolas, um dado e um tabuleiro com casas numeradas de 1 a 5 e uma canaleta numerada 6. O jogo começa com bolas nas casas 1, 3 e 5, e cada jogador tem 15 bolas. O objetivo eh ser o primeiro a eliminar todas as suas bolas. Os jogadores se alternam, rolando o dado quantas vezes quiser, sendo o maximo de vezes possiveis o numero de bolinhas na mao do jogador. O numero no dado determina onde a bola eh colocada:
  1) Se a casa estiver livre, deixa uma bolinha no tabuleiro;
  2) Se a casa estiver ocupada, o jogador pega a bola daquela casa e coloca junto as suas;
  3) Se sair 6, a bola vai para o centro do tabuleiro e fica la.
  ============================= */

int dado(){ // funcao que randomiza valores de 1 ate 6
  return (rand() % 6) + 1;
}
// ========== funcoes para o tabuleiro 
void valeta(int bolas){ // funcao que imprime a qnt d bolinhas no tabuleiro
  int total_space = 32;
  if(bolas > 0){
    printf(" | |");
    for(int i = 0; i < bolas; i++){
      printf("o");
    }
    for(int i =0; i < total_space -bolas; i++){
      printf(" ");
    }
    printf("| |\n");
  }
  else{
    printf(" | |                                | |\n");
  }
}

void tabuleiro(int casas[], int bola6){ // imprime o tabuleiro
  char bola; 
  int tam = 5;

  printf(" ______________________________________\n");
  printf(" |  1    2    3    4    5    6        |\n | ");
  for(int i = 1; i <= tam; i++){
    if(casas[i] == 0){
      bola = 'o';
    }
    else {
      bola = ' ';
    }
    printf("(%c)  ", bola);
  }
  printf("/ /       |\n");
  printf(" | ________________________/ /_______ |\n");
  valeta(bola6);
  printf(" | |                                | |\n");
  printf(" | |                                | |\n");
  printf(" +------------------------------------+\n");
}
// =============== funcoes para o placar 
int compara(const void *a, const void *b) { // funcao para quick sort
  player *player1 = (player *)a;
  player *player2 = (player *)b;
  return player1->rodadas - player2->rodadas;  // ordem crescente
}

void placar(char nome[], int rodadas) { // atualiza o placar
  FILE *file = fopen("placar.txt", "r+");
  if (file == NULL) {
    file = fopen("placar.txt", "w");
    if (file == NULL) {
      printf("Erro ao abrir o placar\n");
    }
  }
  player scores[MAX + 1];
  int n_players = 0;

  while (fscanf(file, "%s\n%d", scores[n_players].nome, &scores[n_players].rodadas) == 2){ // le o nome e rodadas no arquivo
    n_players++; // adiciona ao contador
    if(n_players == MAX) // se o numero de jogadores chegar ao maximo do placar, para
      break;
    }

    strcpy(scores[n_players].nome, nome); // copia a string nome e atribui a variavel nome
    scores[n_players].rodadas = rodadas; 
    n_players++;

    qsort(scores, n_players, sizeof(player), compara); // ordena os valores do placar com quick sort e a funcao compara

    if (n_players > MAX){
      n_players = MAX; // verifica se eh maior que o maximo, 10
    }

    freopen("placar.txt", "w", file); // volta ao inicio reabrindo o arquivo com funcao write 
    for (int i = 0; i < n_players; i++) {
      fprintf(file, "%s\n%d\n", scores[i].nome, scores[i].rodadas);  // escreve no arquivo o placar organizado 
    }
    fclose(file); // fecha o arquivo 
}

void mostra_placar() { // funca que imprime o placar no terminal
  FILE *file = fopen("placar.txt", "r"); //abre o arquivo
  if (file == NULL) printf("+-----------+\n| PLACAR\n| nenhum jogador\n+-----------+\n"); // verifica se ha algo no buffer, se nao, imprime a mensagem ERRO
  player registro[MAX];

  int contagem = 0; // variavel inicializada em 0
  while (fscanf(file, "%s %d", registro[contagem].nome, &registro[contagem].rodadas) == 2) { // le os valores e salva no registro player
    contagem++;// adiciona a contagem ate que ela seja igual a 10 
    if (contagem == MAX) break; 
  }
  printf("\n+-----------+\n| PLACAR\n"); // imprime o cabecalho do placar
  for (int i = 0; i < contagem; i++) {
    printf("| %s %d\n", registro[i].nome, registro[i].rodadas); // impimr todos os jogadores e sua quantidade de rodadas
  }
  printf("+-----------+\n"); // imprime o rodape do placar 
  fclose(file);
}

int main(){
  char nome[30]; // variável nome com no máximo 30 caracteres
  int bolasj = MAX_BOLAS, bolasc = MAX_BOLAS, win = FLAG, rodadas = FLAG, casa6 = FLAG; // bolas do jogador, bolas do computador
  int n_jog, v_dado, tam_nome, ENTER; // número de jogadas, valor do dado, flag se ganhou, tamanho do nome para tratamento, enter para cada jogada
  int casas[6] = {CHEIA, VAZIA, CHEIA, VAZIA, CHEIA, VAZIA}; // vetor com número das casas
  srand(time(NULL)); // semente que inicializa o dado
  
  
  printf("Ola, bem-vindo ao Speculate! Digite seu nome:\n\t"); // mensagem inicial
  fgets(nome, 30, stdin); 
  tam_nome = strlen(nome);
  if(nome[tam_nome - 1] == '\n'){nome[tam_nome - 1] = '\0';} // tratando \n 
  
  while(win == FLAG){ // inicia os turnos
    rodadas++;
    if(bolasj == 0){ win = 1; break;}
    else if(bolasc == 0){win = -1; break;}

    printf("Quantas vezes voce quer jogar o dado, %s? (1-%d)\n\t", nome, bolasj); // pergunta o número de jogadas
    scanf("%d", &n_jog); // armazena na variável n_jog

    if(n_jog < 1){ // se o número de jogadas for menor que 1
      printf("Voce nao pode jogar %d vezes!\n", n_jog);
      n_jog = 1; // joga apenas uma vez
    }
    else if (n_jog > bolasj){ // se o número de jogadas for maior que o número de bolinhas
      printf("Voce soh tem %d bolinhas!\n", bolasj);
      n_jog = bolasj; // joga o máximo de vezes
    }

    // ======================================= TURNO DO JOGADOR ==============================================
    for(int i = 1; i <= n_jog && bolasj != 0; i++){ // repete os lançamentos do jogador  
      v_dado = dado(); // joga o dado
      int casa = v_dado;
      tabuleiro(casas, casa6);
      if(bolasj == 0){ win = 1; break;}
      printf("Dado %d caiu em %d!\n", i, v_dado); // mostra qual dado e qual seu valor
      if (v_dado == 6){  // se o valor do dado for 6
        bolasj--; // retira uma bolinha permanentemente
        casa6++;
        printf("Vai para a valeta! ROLANDo uma bolinha para o centro do tabuleiro...\n");
        printf("%s: %d\nComputador: %d\n", nome, bolasj, bolasc);

      }
      else if(casas[casa] == 0){ // se a casa de mesmo numero do dado esta vazia
        casas[casa] = 1; // casa fica cheia
        bolasj++; // retira uma bolinha
        printf("Casa cheia! Pegando a bolinha da casa %d...\n", v_dado);
        printf("%s: %d\nComputador: %d\n", nome, bolasj, bolasc);

      }
      else if(casas[casa] == 1){ // se a casa de mesmo numero do dado esta cheia
        casas[casa] = 0; // casa fica vazia
        bolasj--; // adiciona uma bolinha
        printf("Casa vazia! colocando uma bolinha na casa %d...\n", v_dado);
        printf("%s: %d\nComputador: %d\n", nome, bolasj, bolasc);

      }
      tabuleiro(casas, casa6);
      printf("Pressione 0 para continuar\n\t"); // atualiza o tabuleiro e a proxima jogada
      scanf("%d", &ENTER);
    }
    if(bolasj == 0){ win = 1; break;} // verifica se o jogador ainda tem bolinhas 
    printf("\n\nAgora eh a vez do computador!\n\n");

    // ======================================= TURNO DE COMPUTADOR ==============================================
    
    int jog_c = bolasc; // numero de jogadas do computador eh igual ao numero de bolas do computador
    for(int i = 1; i <= jog_c && bolasc != 0; i++){ // repete os lançamentos do computador  
      v_dado = dado(); // joga o dado
      int casa = v_dado;
      tabuleiro(casas, casa6); // chama a funcao tabuleiro
      if(bolasc == 0){win = -1; break;} // verifica se o computador ainda tem bolas antes de comecar o seu turno
      
      printf("Dado %d caiu em %d!\n", i, v_dado); // mostra qual dado e qual seu valor
      if (v_dado == 6){  // se o valor do dado for 6
        bolasc--; // retira uma bolinha permanentemente
        casa6++;
        printf("Vai para a valeta! ROLANDo uma bolinha para o centro do tabuleiro...\n");
        printf("%s: %d\nComputador: %d\n", nome, bolasj, bolasc);

      }
      else if(casas[casa] == 0){ // se a casa de mesmo numero do dado esta vazia
        casas[casa] = 1; // casa fica cheia
        bolasc++; // retira uma bolinha
        printf("Casa cheia! Pegando a bolinha da casa %d...\n", v_dado);
        printf("%s: %d\nComputador: %d\n", nome, bolasj, bolasc);

      }
      else if(casas[casa] == 1){ // se a casa de mesmo numero do dado esta cheia
        casas[casa] = 0; // casa fica vazia
        bolasc--; // adiciona uma bolinha
        printf("Casa vazia! colocando uma bolinha na casa %d...\n", v_dado);
        printf("%s: %d\nComputador: %d\n", nome, bolasj, bolasc);

      }
      tabuleiro(casas, casa6); // chama a funcao tabuleiro
      printf("Pressione 0 para continuar\n\t"); // atualiza o tabuleiro e a proxima jogada 
      scanf("%d", &ENTER);

    } // ================================= FIM DAS RODADAS ===================================

    printf("Numero de bolinhas atual: %d\n\n", bolasj); // mostra a quantidade de bolinhas
    if(bolasj > 0 || bolasc > 0){printf("Agora eh a sua vez!\n\n");}
    if(bolasj == 0){win = 1; break;} // se o numero de bolinhas do jogador for 0, para o while
    if(bolasc == 0){win = -1; break;} // se o numero de bolinhas do computador for 0, para o while
  }

  if(win == -1){ // se o computador ganhar
    printf("Vitoria da maquina!\n");
    mostra_placar();
  }
  else if(win == 1){ // se o jogador ganhar
    printf("Parabens! Vitória de %s!\n", nome);
    placar(nome, rodadas);
    mostra_placar();
  }
  return 0;
}
