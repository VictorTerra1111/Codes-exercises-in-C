#include <stdio.h>
#include <stdlib.h>

/*
Título:  Exercicio007.C;
Nome:  João Victor Terra Pereira;
Objetivo: Faca um programa que receba tres numeros e mostre o maior
Data:  31/03/2024;
*/
int main(){
  double a, b, c;

  scanf("%lf %lf %lf", &a, &b, &c);

  if (a > b && a > c){
    printf("%.4f", a);
  }
  else if (b > a && b > c){
    printf("%.4f", b);
  }
  else if (c > a && c > b){
    printf("%.4f", c);
  }
  else if (a == b && b == c){
    printf("%.4f", a);
  }
  return 0;
}