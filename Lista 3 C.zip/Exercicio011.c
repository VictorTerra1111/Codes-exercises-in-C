#include <stdio.h>
#include <stdlib.h>
/*
Título:  Exercicio008.C;
Nome:  João Victor Terra Pereira;
Objetivo: Faca um programa que receba quatro valores: I, A, B e C. Desses valores, I e inteiro e positivo, A, B e C sao reais. Escreva os numeros A, B e C obedecendo a tabela a seguir. Suponha que o valor digitado para I seja sempre um valor valido, ou seja, 1, 2 ou 3.
Data:  31/03/2024;
*/
int main() {
    int i;
    double a, b, c;

    scanf("%d %lf %lf %lf", &i, &a, &b, &c);

    // Casos para i = 1
    if (i == 1) {
        if (a > b) {
            if (b > c)
                printf("%.4f %.4f %.4f\n", c, b, a);
            else if (a > c)
                printf("%.4f %.4f %.4f\n", b, c, a);
            else
                printf("%.4f %.4f %.4f\n", b, a, c);
        } else {
            if (a > c)
                printf("%.4f %.4f %.4f\n", c, a, b);
            else if (b > c)
                printf("%.4f %.4f %.4f\n", a, c, b);
            else
                printf("%.4f %.4f %.4f\n", a, b, c);
        }
    }
    // Casos para i = 2
    else if (i == 2) {
        if (a > b) {
            if (a > c)
                printf("%.4f %.4f %.4f\n", a, b, c);
            else if (b > c)
                printf("%.4f %.4f %.4f\n", a, c, b);
            else
                printf("%.4f %.4f %.4f\n", c, a, b);
        } else {
            if (b > c)
                printf("%.4f %.4f %.4f\n", b, a, c);
            else if (a > c)
                printf("%.4f %.4f %.4f\n", b, c, a);
            else
                printf("%.4f %.4f %.4f\n", c, b, a);
        }
    }
    // Casos para i = 3
    else if (i == 3) {
        if (a > b) {
            if (c > a)
                printf("%.4f %.4f %.4f\n", b, c, a);
            else if (b > c)
                printf("%.4f %.4f %.4f\n", c, a, b);
            else
                printf("%.4f %.4f %.4f\n", b, a, c);
        } else {
            if (a == b && c > b)
                printf("%.4f %.4f %.4f\n", a, c, b);
            if (a == b && c < b)
                printf("%.4f %.4f %.4f\n", c, a, a);
            else if (a > c && a < b)
                printf("%.4f %.4f %.4f\n", c, b, a);
            else if (a > c && a > b)
                printf("%.4f %.4f %.4f\n", c, b, a);
            else if (a < b && b < c){
                printf("%.4f %.4f %.4f\n", a, c, b);
            }
            else
                printf("%.4f %.4f %.4f\n", a, b, c);
        }
    }

    return 0;
}
