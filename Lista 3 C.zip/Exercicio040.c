#include <stdio.h>
#include <stdlib.h>
 /*
 Título:  Exercicio040.C;
 Nome:  João Victor Terra Pereira;
 Objetivo: Dados tres valores X, Y e Z, verifique se eles podem ser os comprimentos dos lados de um tri ˆ angulo, e, se forem, verifique se e um triangulo equilatero (“EQUILATERO”), isosceles (“ISOSCELES”) ou escaleno (“ESCALENO”). Se eles nao formarem um triangulo, escreva a mensagem “NAO EH TRIANGULO”. Considere que o comprimento de cada lado de um triangulo e menor que a soma dos outros dois lados; chama-se equilatero o triangulo que tem tres lados iguais; denomina-se isosceles o triangulo que tem o comprimento de dois lados iguais; recebe o nome de escaleno o triangulo que tem os tres lados diferentes.
 Data:  31/03/2024;
 */

int main(){
  double x, y, z;
  scanf("%lf %lf %lf", &x, &y, &z);

  if (x < (y + z) && y < (x + z) && z < (x + y)){
    if (x == y && y == z){
      printf("EQUILATERO");
    }
    else if (x == y || x == z || y == z){
      printf("ISOSCELES");
    }
    else{
      printf("ESCALENO");
    }
  }
  else{
    printf("NAO EH TRIANGULO");
  }
}