#include <stdio.h>
#include <stdlib.h>
/*
Título:  Exercicio031.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Uma agencia bancaria possui dois tipos de investimentos, conforme o quadro a seguir. Faca um programa que receba o tipo de investimento e seu valor, calcule e mostre o valor corrigido apos um mes de investimento, de acordo com o tipo de investimento.
Data:  31/03/2024;
*/
int main(){
  int inv;
  double valor, final;
  scanf("%d %lf", &inv, &valor);

  if (inv == 1){
    final = valor + (valor * 0.03);
  }
  else if (inv == 2){
    final = valor + (valor * 0.04);
  }
  printf("%.4f", final);
  return 0;
}