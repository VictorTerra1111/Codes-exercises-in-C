#include <stdio.h>
#include <stdlib.h>
/*
Título:  Exercicio026.C;
Nome:  João Victor Terra Pereira;
Objetivo: Uma empresa decidiu dar uma gratificac¸ao de Natal a seus funcionarios, baseada no numero de horas extras e no numero de horas que o funcionario faltou ao trabalho. O valor do premio e obtido pela consulta a tabela que se segue, na qual: H = numero de horas extras - 2/3 × numero de horas faltadas.
Data:  31/03/2024;
*/
int main(){
  double num_extra, num_falt, h;
  scanf("%lf %lf", &num_extra, &num_falt);

  h = (num_extra - ((2.0/3) * num_falt)) * 60;

  if(h>= 2400){
    printf("500.0000");
  }
  else if (h >=1800 && h < 2400){
    printf("400.0000");
  }
  else if(h >= 1200 && h < 1800){
    printf("300.0000");
  }
  else if(h >= 600 && h < 1200){
    printf("200.0000");
  }
  else if(h < 600){
    printf("100.0000");
  }
  return 0;
}