#include <stdio.h>
#include <stdlib.h>
/*
Título:  Exercicio027.C;
Nome:  João Victor Terra Pereira;
Objetivo: Faca um programa que receba o salario atual de um funcionario e, usando a tabela a seguir, calcule e mostre o valor do aumento e o novo salario.
Data:  31/03/2024;
*/
int main(){
  double sal, final, aumento;
  scanf("%lf", &sal);

  if (sal <= 300){
    aumento = (sal * 0.15);
    final = aumento + sal;
    printf("%.4f %.4f", aumento, final);
  }
  else if (sal > 300 && sal < 600){
    aumento = (sal * 0.10);
    final = aumento + sal;
    printf("%.4f %.4f", aumento, final);
  }
  else if (sal >= 600 && sal <= 900){
    aumento = (sal * 0.05);
    final = aumento + sal;
    printf("%.4f %.4f", aumento, final);
  }
  else {
    aumento = 0.0;
    final = sal;
      printf("%.4f %.4f", aumento, final);
  }
  return 0;
}