#include <stdio.h>
#include <stdlib.h>
/*
Título:  Exercicio003.C;
Nome:  João Victor Terra Pereira;
Objetivo: Faça um programa que receba tres notas, calcule e mostre a media aritmetica e a mensagem que se encontra na tabela.
Data:  31/03/2024;
*/
int main(){
  double nota1, nota2, nota3, final;
  scanf("%lf %lf %lf", &nota1, &nota2, &nota3);

  final = (nota1 + nota2 + nota3) /3;

  if (final < 3){
    printf("%.4f Reprovado", final);
  }
  else if(final >= 3 && final < 7){
    printf("%.4f Exame", final);
  }
  else if(final >= 7){
    printf("%.4f Aprovado", final);
  }
  return 0;
}