#include <stdio.h>
#include <stdlib.h>
 /*
 Título:  Exercicio033.C;
 Nome:  João Victor Terra Pereira;
 Objetivo: Faça um programa que receba o salario atual de um funcionario e, usando a tabela a seguir, calcule e mostre o valor do aumento e o novo salario.
 Data:  31/03/2024;
 */

int main() {
  double h, peso;
  char sexo[2];
  scanf("%lf %s", &h, &sexo);

  if (sexo[0] == 'M') {
      peso = (72.7 * h)-58;
      printf("%.4f\n", peso);
  }
  else if (sexo[0] == 'F') {
    peso = (62.1* h) - 44.7;
    printf("%.4f\n", peso);  
  }
  return 0;
}