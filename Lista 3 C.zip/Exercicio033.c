#include <stdio.h>
#include <stdlib.h>
 /*
 Título:  Exercicio033.C;
 Nome:  João Victor Terra Pereira;
 Objetivo: Uma empresa decide aplicar descontos nos seus precos usando a tabela a seguir. Fac¸a um programa que receba o preco atual de um produto, calcule e mostre o valor do desconto e o novo preco.
 Data:  31/03/2024;
 */
int main(){
  double preco, novo, desconto;
  scanf("%lf", &preco);

  if(preco <= 30){
    desconto = 0;
    novo = preco;
    printf("%.4f %.4f", desconto, novo);
  }
  else if(preco > 30 && preco <= 100){
    desconto = preco * 0.10;
    novo = preco - desconto;
    printf("%.4f %.4f", desconto, novo);
  }
  else if(preco > 100){
    desconto = preco * 0.15;
    novo = preco - desconto;
    printf("%.4f %.4f", desconto, novo);
  }
  return 0;
}