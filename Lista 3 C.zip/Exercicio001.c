#include <stdio.h>
#include <stdlib.h>
/*
Título:  Exercicio001.C;
Nome:  João Victor Terra Pereira;
Objetivo:  A nota final de um estudante e calculada a partir de tres notas atribuıdas, respectivamente, a um trabalho de laboratorio, a uma avaliacao semestral e a um exame final. A média das tres notas mencionadas obedece aos pesos a seguir. Faca um programa que receba as tres notas, calcule e mostre a media ponderada e o conceito que segue a tabela.
Data:  31/03/2024;
*/
int main(){
  double Trab, ava, exa, nota_f;

  scanf("%lf %lf %lf", &Trab, &ava, &exa);
  nota_f = ((2 * Trab) + (3 *ava) + (5 * exa)) / 10;

  if (nota_f >= 8) {
    printf("%.4f A", nota_f);
  }
  else if (nota_f >= 7 && nota_f < 8){
    printf("%.4f B", nota_f);
  }
  else if (nota_f >= 6 && nota_f < 7){
    printf("%.4f C", nota_f);
  }
  else if (nota_f >= 5 && nota_f < 6){
    printf("%.4f D", nota_f);
  }
  else if (nota_f >= 0 && nota_f < 5){
    printf("%.4f E", nota_f);
  }
  return 0;
}