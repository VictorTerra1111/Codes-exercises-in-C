#include <stdio.h>
#include <stdlib.h>
/*
Título:  Exercicio008.C;
Nome:  João Victor Terra Pereira;
Objetivo: Faca um programa que receba tres numeros e mostre-os em ordem crescente.
Data:  31/03/2024;
*/
int main(){
  double a, b, c;
  
  scanf("%lf %lf %lf", &a, &b, &c);
  if (a > b) {
      if (b > c)
          printf("%.4f %.4f %.4f\n", c, b, a);
      else if (a > c)
          printf("%.4f %.4f %.4f\n", b, c, a);
      else
          printf("%.4f %.4f %.4f\n", b, a, c);
  } else {
      if (a > c)
          printf("%.4f %.4f %.4f\n", c, a, b);
      else if (b > c)
          printf("%.4f %.4f %.4f\n", a, c, b);
      else
          printf("%.4f %.4f %.4f\n", a, b, c);
  }
  return 0;
}