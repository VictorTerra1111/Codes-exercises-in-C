#include <stdio.h>
#include <stdlib.h>
/*
  Título:  Exercicio015.C;
  Nome:  João Victor Terra Pereira;
  Objetivo:Faca um programa que leia 5 numeros correspondendo respectivamente a dia, mees, ano, horas e minutos e mostre a data e a hora nos seguintes formatos: DD/MM/AAAA - mes por extenso e hora:minuto. Use exatamente as seguintes grafias (sem acentos ou cedilha) para os nomes dos meses: “janeiro”, “fevereiro”, “marco”, “abril”, “maio”, “junho”, “julho”, “agosto”, “setembro”, “outubro”, “novembro” e“dezembro”.
  Data:  31/03/2024;
  */  
int main(){
  int dia, mes, ano, hr, min;
  scanf("%d %d %d %d %d", &dia, &mes, &ano, &hr, &min);
  if (dia < 10){
    if (hr < 10 && min < 10){
      if (mes == 1){
        printf("0%d/0%d/%d - janeiro\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 2){
        printf("0%d/0%d/%d - fevereiro\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 3){
        printf("0%d/0%d/%d - marco\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 4){
        printf("0%d/0%d/%d - abril\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 5){
        printf("0%d/0%d/%d - maio\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 6){
        printf("0%d/0%d/%d - junho\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 7){
        printf("0%d/0%d/%d - julho\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 8){
        printf("0%d/0%d/%d - agosto\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 9){
        printf("0%d/0%d/%d - setembro\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 10){
        printf("0%d/%d/%d - outubro\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 11){
        printf("0%d/%d/%d - novembro\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 12){
        printf("0%d/%d/%d - dezembro\n0%d:0%d", dia, mes, ano, hr, min);
      }
    }
    else if (hr < 10 && min > 10){
      if (mes == 1){
        printf("0%d/0%d/%d - janeiro\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 2){
        printf("0%d/0%d/%d - fevereiro\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 3){
        printf("0%d/0%d/%d - marco\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 4){
        printf("0%d/0%d/%d - abril\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 5){
        printf("0%d/0%d/%d - maio\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 6){
        printf("0%d/0%d/%d - junho\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 7){
        printf("0%d/0%d/%d - julho\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 8){
        printf("0%d/0%d/%d - agosto\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 9){
        printf("0%d/0%d/%d - setembro\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 10){
        printf("0%d/%d/%d - outubro\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 11){
        printf("0%d/%d/%d - novembro\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 12){
        printf("0%d/%d/%d - dezembro\n0%d:%d", dia, mes, ano, hr, min);
      }
    }
    else if (hr > 10 && min < 10){
      if (mes == 1){
        printf("0%d/0%d/%d - janeiro\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 2){
        printf("0%d/0%d/%d - fevereiro\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 3){
        printf("0%d/0%d/%d - marco\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 4){
        printf("0%d/0%d/%d - abril\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 5){
        printf("0%d/0%d/%d - maio\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 6){
        printf("0%d/0%d/%d - junho\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 7){
        printf("0%d/0%d/%d - julho\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 8){
        printf("0%d/0%d/%d - agosto\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 9){
        printf("0%d/0%d/%d - setembro\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 10){
        printf("0%d/%d/%d - outubro\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 11){
        printf("0%d/%d/%d - novembro\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 12){
        printf("0%d/%d/%d - dezembro\n%d:0%d", dia, mes, ano, hr, min);
      }
    }
    else if (hr > 10 && min > 10){
      if (mes == 1){
        printf("0%d/0%d/%d - janeiro\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 2){
        printf("0%d/0%d/%d - fevereiro\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 3){
        printf("0%d/0%d/%d - marco\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 4){
        printf("0%d/0%d/%d - abril\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 5){
        printf("0%d/0%d/%d - maio\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 6){
        printf("0%d/0%d/%d - junho\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 7){
        printf("0%d/0%d/%d - julho\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 8){
        printf("0%d/0%d/%d - agosto\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 9){
        printf("0%d/0%d/%d - setembro\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 10){
        printf("0%d/%d/%d - outubro\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 11){
        printf("0%d/%d/%d - novembro\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 12){
        printf("0%d/%d/%d - dezembro\n%d:%d", dia, mes, ano, hr, min);
      }
    }
  }
  else if (dia > 10){
    if (hr < 10 && min < 10){
      if (mes == 1){
        printf("%d/0%d/%d - janeiro\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 2){
        printf("%d/0%d/%d - fevereiro\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 3){
        printf("%d/0%d/%d - marco\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 4){
        printf("%d/0%d/%d - abril\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 5){
        printf("%d/0%d/%d - maio\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 6){
        printf("%d/0%d/%d - junho\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 7){
        printf("%d/0%d/%d - julho\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 8){
        printf("%d/0%d/%d - agosto\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 9){
        printf("%d/0%d/%d - setembro\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 10){
        printf("%d/%d/%d - outubro\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 11){
        printf("%d/%d/%d - novembro\n0%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 12){
        printf("%d/%d/%d - dezembro\n0%d:0%d", dia, mes, ano, hr, min);
      }
    }
    else if (hr < 10 && min > 10){
      if (mes == 1){
        printf("%d/0%d/%d - janeiro\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 2){
        printf("%d/0%d/%d - fevereiro\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 3){
        printf("%d/0%d/%d - marco\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 4){
        printf("%d/0%d/%d - abril\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 5){
        printf("%d/0%d/%d - maio\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 6){
        printf("%d/0%d/%d - junho\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 7){
        printf("%d/0%d/%d - julho\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 8){
        printf("%d/0%d/%d - agosto\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 9){
        printf("%d/0%d/%d - setembro\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 10){
        printf("%d/%d/%d - outubro\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 11){
        printf("%d/%d/%d - novembro\n0%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 12){
        printf("%d/%d/%d - dezembro\n0%d:%d", dia, mes, ano, hr, min);
      }
    }
    else if (hr > 10 && min < 10){
      if (mes == 1){
        printf("%d/0%d/%d - janeiro\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 2){
        printf("%d/0%d/%d - fevereiro\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 3){
        printf("%d/0%d/%d - marco\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 4){
        printf("%d/0%d/%d - abril\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 5){
        printf("%d/0%d/%d - maio\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 6){
        printf("%d/0%d/%d - junho\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 7){
        printf("%d/0%d/%d - julho\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 8){
        printf("%d/0%d/%d - agosto\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 9){
        printf("%d/0%d/%d - setembro\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 10){
        printf("%d/%d/%d - outubro\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 11){
        printf("%d/%d/%d - novembro\n%d:0%d", dia, mes, ano, hr, min);
      }
      else if (mes == 12){
        printf("%d/%d/%d - dezembro\n%d:0%d", dia, mes, ano, hr, min);
      }
    }
    else if (hr > 10 && min > 10){
      if (mes == 1){
        printf("%d/0%d/%d - janeiro\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 2){
        printf("%d/0%d/%d - fevereiro\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 3){
        printf("%d/0%d/%d - marco\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 4){
        printf("%d/0%d/%d - abril\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 5){
        printf("%d/0%d/%d - maio\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 6){
        printf("%d/0%d/%d - junho\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 7){
        printf("%d/0%d/%d - julho\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 8){
        printf("%d/0%d/%d - agosto\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 9){
        printf("%d/0%d/%d - setembro\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 10){
        printf("%d/%d/%d - outubro\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 11){
        printf("%d/%d/%d - novembro\n%d:%d", dia, mes, ano, hr, min);
      }
      else if (mes == 12){
        printf("%d/%d/%d - dezembro\n%d:%d", dia, mes, ano, hr, min);
      }
    }
  }
  return 0;
}