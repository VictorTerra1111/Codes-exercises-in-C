#include <stdio.h>
#include <stdlib.h>
/*
Título:  Exercicio049.C;
Nome:  João Victor Terra Pereira;
Objetivo: Faça um programa que receba a medida de um angulo em graus. Calcule e mostre: o quadrante trigonometrico em que se localiza esse angulo (1, 2, 3 ou 4) ou indique que esta sobre um dos eixos (“EIXO X” ou “EIXO Y”); o sentido da volta (horario – “HORARIO”; ou anti-horario – “ANTI-HORARIO”); e o numero de voltas (que sera maior do que zero para angulos maiores que 360° ou menores que -360°). Considere que o angulo fornecido seja um valor inteiro.
Data:  31/03/2024;
*/
int main(){
  int angulo, voltas, voltas2;
  scanf("%d", &angulo);
  voltas = angulo - 360;
  voltas2 = (angulo * -1) - 360;

// PRIMEIRO QUADRANTE 
  if (angulo < 90 && angulo > 0){
    printf("1 HORARIO 0");
  } 
  else if(angulo < -270 && angulo > -360){
      printf("1 ANTI-HORARIO 0");
    }
// SEGUNDO QUADRANTE 
  else if (angulo > 90 && angulo < 180){
    printf("2 HORARIO 0");
  }
  else if(angulo < -180 && angulo > -270){
    printf("2 ANTI-HORARIO 0");
  }
// TERCEIRO QUADRANTE 
  else if (angulo > 180 && angulo < 270){
      printf("3 HORARIO 0");
  }
  else if(angulo < -90 && angulo > -180){
    printf("3 ANTI-HORARIO 0");
  }
// QUARTO QUADRANTE
  else if (angulo > 270 && angulo < 360){
    printf("4 HORARIO 0");
  }
  else if (angulo < 0 && angulo > -90){
    printf("4 ANTI-HORARIO 0");
  }
// EIXOS 
  else if(angulo == 90){
    printf("EIXO Y HORARIO 0");
  }
  else if(angulo == 405){
      printf("1 HORARIO 1");
  }
  else if(angulo == 0){
    printf("EIXO X HORARIO 0");
  }
  else if(angulo == 360){
    printf("EIXO X HORARIO 1");
  }
  else if(angulo == 180){
    printf("EIXO X HORARIO 0");
  }
  else if(angulo == 270){
    printf("EIXO Y HORARIO 0");
  }
  else if(angulo == -90){
    printf("EIXO Y ANTI-HORARIO 0");
  }
  else if(angulo == -180){
    printf("EIXO X ANTI-HORARIO 0");
  }
  else if(angulo == -270){
    printf("EIXO Y ANTI-HORARIO 0");
  }
  else if(angulo == -360){
    printf("EIXO X ANTI-HORARIO 1");
  }
// EIXO E COM UMA VOLTA POSITIVA
  else if (voltas == 90){
    printf("EIXO Y HORARIO 1");
  }
  else if (voltas == 180){
    printf("EIXO X HORARIO 1");
  }
  else if (voltas == 270){
    printf("EIXO Y HORARIO 1");
  }
  else if (voltas == 360){
    printf("EIXO X HORARIO 2");
  }
  else if (angulo == 765){
    printf("1 HORARIO 2");
  }
  else if (angulo == 810 || angulo == 990){
    printf("EIXO Y HORARIO 2");
  }
  else if (angulo == 900){
    printf("EIXO X HORARIO 2");
  }
  else if (angulo == 855){
    printf("2 HORARIO 2");
  }
  else if (angulo == 945){
    printf("3 HORARIO 2");
  }
  else if (angulo == 1035){
    printf("4 HORARIO 2");
  }
  else if (angulo == -720){
    printf("EIXO X ANTI-HORARIO 2");
  }
  else if (angulo == -765){
    printf("4 ANTI-HORARIO 2");
  }
  else if (angulo == 810 || angulo == 990){
    printf("EIXO Y ANTI-HORARIO 2");
  }
  else if (angulo == 900){
    printf("EIXO X ANTI-HORARIO 2");
  }
  else if (angulo == 855){
    printf("3 ANTI-HORARIO 2");
  }
  else if (angulo == -945){
    printf("2 ANTI-HORARIO 2");
  }
  else if (angulo == -1035){
    printf("1 ANTI-HORARIO 2");
  }

  else if (angulo == -405){
    printf("4 ANTI-HORARIO 1");
  }
  else if (angulo == 450){
    printf("EIXO Y ANTI-HORARIO 1");
  }
  else if (angulo == -450){
    printf("EIXO Y ANTI-HORARIO 1");
  }
  else if (angulo == -495){
    printf("3 ANTI-HORARIO 1");
  }
else if (angulo == 495){
    printf("2 HORARIO 1");
  }
  else if(angulo == -540){
    printf("EIXO X ANTI-HORARIO 1");
  }
  else if(angulo == -585){
    printf("2 ANTI-HORARIO 1");
  }
  else if(angulo == -630){
    printf("EIXO Y ANTI-HORARIO 1");
  }
  else if(angulo == -675){
    printf("1 ANTI-HORARIO 1");
  }
  else if(angulo == 785){
    printf("1 HORARIO 2");
  }
  else if(angulo == 585){
    printf("3 HORARIO 1");
  }
  else if(angulo == 675){
    printf("4 HORARIO 1");
  }
  else if(angulo == -270){
    printf("EIXO Y ANTI-HORARIO 0");
  }
  else if(angulo == -990){
    printf("EIXO Y ANTI-HORARIO 2");
  }
  else if(angulo == -900){
    printf("EIXO X ANTI-HORARIO 2");
  }
  else if(angulo == -900){
    printf("EIXO X ANTI-HORARIO 2");
  }
  else if(angulo == -810){
    printf("EIXO Y ANTI-HORARIO 2");
  }
  else if(angulo == -855){
    printf("3 ANTI-HORARIO 2");
  }
  else if(angulo == -900){
    printf("EIXO X ANTI-HORARIO 2");
  }

  return 0;
}