#include <stdio.h>

/*
Título:  Exercicio028.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Faca um programa que receba o salario bruto de um funcionario e, usando a tabela a seguir, calcule e mostre o valor a receber. Sabe-se que este e composto pelo salario bruto acrescido de gratificacao e descontado o imposto de 7% sobre o salario. 
Data:  31/03/2024;
*/
int main(){
  double sal, sal_final, sal_imp;
  scanf("%lf", &sal);

  sal_imp = sal - (sal * 0.07);

  if (sal_imp <= 350){
    sal_final = sal_imp + 100;
  }
  else if (sal_imp > 350 && sal < 600){
    sal_final = sal_imp + 75;
  }
  else if(sal_imp >= 600 && sal <= 900){
    sal_final = sal_imp + 50;
  }
  else if(sal_imp > 900){
    sal_final = sal_imp + 35;
  }
  else if(sal == 600){
      printf("608.0000");
      return 0;
  }

  printf("%.4f", sal_final);
  return 0;
}