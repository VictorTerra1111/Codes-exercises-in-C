#include <stdio.h>

/*
Título:  Exercicio111.C;
Nome:  João Victor Terra Pereira;
Objetivo:  
Escrever um programa que le um numero nao determinado de valores a, todos inteiros e positivos, um de cada vez (ate que um valor negativo seja lido), e calcule e escreva a media aritmetica dos valores lidos, bem como, a quantidade de valores pares, a quantidade de valores ımpares, a porcentagem dos valores pares e a porcentagem dos valores ımpares (expressas como um valor de 0.0000 a 100.0000). Se nenhum valor positivo for fornecido, imprimir “*” no lugar da media e das percentagens.  
Data:  17/04/2024;
*/

int main(){
  int a, i = 0, par = 0, imp = 0;
  double porpar, porimp, media, soma = 0.0;

  while (scanf("%d", &a) && a >= 0){
    i++;
    soma = a + soma;
    // checa se é par
    if (a % 2 == 0){
      par++;
    }
    // checa se é impar
    else{
      imp++;
    }
  }
  porpar = (par * 100) / i;
  porimp = (imp * 100) / i;
  media = soma / i;
  if (i > 0){
    printf("%.4f %d %d %.4f %.4f\n", media, par, imp, porpar, porimp);
  }
  else {
    printf("* %d %d * * \n", par, imp);
  }
  return 0;
}