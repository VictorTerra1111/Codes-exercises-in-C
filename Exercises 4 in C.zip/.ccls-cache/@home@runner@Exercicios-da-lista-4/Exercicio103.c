#include <stdio.h>
/*
Título:  Exercicio103.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Escrever um programa que le 10 valores reais, um de cada vez, e conta quantos deles estao no intervalo [10,20] e quantos deles estao fora deste intervalo, escrevendo estas informacoes. 
Data:  17/04/2024;
*/
int main(){
  double num;
  int dentro = 0, fora = 0;

  for (int i = 0; i <10; i++){
    scanf("%lf", &num);
    if (num >= 10 && num <= 20){
      dentro = dentro + 1;
    }
    else {
      fora = fora + 1;
    }
  }
  printf("%d %d", dentro, fora);
  return 0;
}