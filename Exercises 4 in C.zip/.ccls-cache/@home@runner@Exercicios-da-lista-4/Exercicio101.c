#include <stdio.h>

/*
Título:  Exercicio101.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Escrever um programa que le 5 valores reais para a, um de cada vez, e conta quantos destes valores sao negativos, escrevendo esta informacao.
Data:  17/04/2024;
*/
int main(){
  double num, n = 0, p;

  for (double i = 0; i < 5; i = i + 1){
    scanf("%lf", &num);
    if (num < 0){
      n = n + 1;
    }
    else {
      p = p + 1;
    }
  }
  printf("%.0f",n);
  return 0;
}