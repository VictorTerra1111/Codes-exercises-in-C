#include <stdio.h>

/*
Título:  Exercicio016.C;
Nome:  João Victor Terra Pereira;
Objetivo: Faca um programa para calcular a area de um triangulo (a partir de sua base e altura, declarados e lidos como valores reais) e que nao permita a entrada de dados invalidos, ou seja, medidas menores ou iguais a 0. Na entrada, sempre havera dois valores validos para base e altura, cada um podendo ser precedido ou nao por valores invalidos (menores ou iguais a zero). 
Data:  17/04/2024;
*/

int main() {
  double num1 = 0, num2 = 0;
  int contador_positivos = 0;

  while (contador_positivos < 2 && scanf("%lf", &num1) == 1) {
    if (num1 > 0) {
      contador_positivos++;
      if (contador_positivos == 1) {
        num2 = num1;
      } 
      else {
        break; 
      }
    }
  }
  double a = (num1 * num2) / 2;
  printf("%.4f\n", a);

    return 0;
}