#include <stdio.h>
/*
Título:  Exercicio117.C;
Nome:  João Victor Terra Pereira;
Objetivo:  
  Escrever um programa que le um valor ˆ n, inteiro e positivo, e que calcula e escreve o valor de E, onde:
  e = 1 + 1/1! + ... + 1/n!
Data:  17/04/2024;
*/
int main() {
  int n;
  double e = 1.0, fat = 1.0; 

  scanf("%d", &n);

  for (int j = 1; j <= n; j++) {
    fat *= j;
    e = e + 1.0 / fat; 
  }
  printf("%.4f", e);
  return 0;
}