#include <stdio.h>
#include <math.h>

/*
Título:  Exercicio126.C;
Nome:  João Victor Terra Pereira;
Objetivo: Escrever um programa que le um valor n que indica quantos valores devem ser lidos para m, valores todos inteiros e positivos, com leitura de um valor de cada vez. Escreva, para cada valor lido, o proprio valor lido, seu fatorial e sua raiz cubica. 
Data:  17/04/2024;
*/
int main() {
  int n = 0, m;
  double raiz;

  scanf("%d", &n);

  for (int j = 0; j < n; j++) {
    scanf("%d", &m);

    long long fat = 1; 
    for (int i = 1; i <= m; ++i) {
      fat *= i;
    }

    raiz = pow(m, 1.0 / 3.0);

    printf("%d %lld %.4f\n", m, fat, raiz);
  }
  return 0;
}