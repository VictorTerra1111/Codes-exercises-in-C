#include <stdio.h>
#include <math.h>

/*
Título:  Exercicio126.C;
Nome:  João Victor Terra Pereira;
Objetivo: Escrever um programa que le um valor n que indica quantos valores devem ser lidos para m, valores todos inteiros e positivos, com leitura de um valor de cada vez. Escreva, para cada valor lido, o proprio valor lido, seu fatorial e sua raiz cubica. 
Data:  17/04/2024;
*/
int main() {
  int idade, maiori = 0, menori = 999, f500 = 0;
    char sexo;
    double sal, sal_med = 0.0, sal_medfinal;
    int pessoas = 0;

    while (scanf("%d", &idade) && idade >= 0) {
        scanf(" %c %lf", &sexo, &sal);

        sal_med += sal;
        pessoas++;

        if (sexo == 'F' && sal <= 500) {
            f500++;
        }

        if (idade > maiori) {
            maiori = idade;
        }

        if (idade < menori) {
            menori = idade;
        }
    }
  if (f500 != 0){
    sal_medfinal = sal_med / pessoas;
    printf("%.4f %d %d %d\n", sal_medfinal, maiori, menori, f500);
  }
  else {
    return 0;
  }
    return 0;
}