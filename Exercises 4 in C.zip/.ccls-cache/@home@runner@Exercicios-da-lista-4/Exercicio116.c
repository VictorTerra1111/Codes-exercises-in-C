#include <stdio.h> 
/*
Título:  Exercicio116.C;
Nome:  João Victor Terra Pereira;
Objetivo:  
  Escrever um programa que le um numero nao determinado de conjuntos de valores, cada um formado pelo numero do aluno (um valor inteiro) e suas 3 notas. O programa deve encerrar quando um numero negativo for fornecido como numero de aluno. Calcular, para cada aluno, a media ponderada com pesos respectivos de 4 para a maior nota e peso 3 para as outras duas. Escrever o numero do aluno, a media calculada e uma mensagem “APROVADO” se a nota for ≥ 5 ou “REPROVADO” se nota < 5 
Data:  17/04/2024;
*/
int main(){
  int num;
  double n1, n2, n3, maior, media;
  
  while (scanf("%d", &num) && num > 0){
    scanf("%lf %lf %lf", &n1, &n2, &n3);

    if (n1 > n2 && n1 > n3){
      maior = n1 * 4; 
      media = (maior + (n2 * 3) + (n3 * 3))/ 10;
    }
    else if (n2 > n1 && n2 > n3){
      maior = n2 * 4;
      media = (maior + (n1 * 3) + (n3 * 3))/ 10;
    }
    else if (n3 > n1 && n3 > n2){
      maior = n3 * 4;
      media = (maior + (n2 * 3) + (n1 * 3))/ 10;
    }
    else {
      media = n1;
    }
    
    if (media >= 5){
      printf("%d %.4f APROVADO\n", num, media);
    }
    else {
      printf("%d %.4f REPROVADO\n", num, media);
    }
  }
  return 0;
}