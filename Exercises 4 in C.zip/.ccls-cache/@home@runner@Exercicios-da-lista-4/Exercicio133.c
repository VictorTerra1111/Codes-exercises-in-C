#include <stdio.h>
/*
Título:  Exercicio133.C;
Nome:  João Victor Terra Pereira;
Objetivo: Escrever um programa que le o codigo (valor inteiro) e o valor de cada produto de uma empresa (valor real). Supondo que a empresa deseja aumentar todos os produtos de codigos pares em 15% e todos os produtos cujos codigos sao ımpares em 20%, escreva a lista dos produtos com o respectivo codigo e o seu preco ja reajustado. O programa termina quando entrar um codigo nulo.
Data:  17/04/2024;
*/
int main(){
  int code;
  double valor, final;

  while(scanf("%d", &code) && code !=0){
    scanf("%lf", &valor);
    if (code % 2 == 0){
      final = valor * 1.15;
      printf("%d %.4f\n", code, final);
    }
    else {
      final = valor * 1.20;
      printf("%d %.4f\n", code, final);
    }
  }
  return 0;
}