#include <stdio.h>
#include <math.h>
  /*
Título:  Exercicio106.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Escrever um programa que lê p, u e r respectivamente o primeiro termo de uma progressao aritmética, o último termo da progressao e a sua razão. Determinar e imprimir a soma dos termos desta progressão;
Data:  19/03/2024;
  */
int main(){
  double p, u, r, soma, ult_ele;
  printf("\n");
  scanf("%lf %lf %lf", &p, &u, &r);
  ult_ele = ((-p + u) / r) + 1.0;
  soma = ((p + u)* ult_ele) / 2.0;
  printf("%.4f", soma);
  return 0;
}