#include <stdio.h>
#include <math.h>
  /*
Título:  Exercicio105.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Imprimir impares entre 10 e 20;
Data:  19/03/2024;
  */
int main(){
  printf("11 13 15 17 19");
  return 0;
}