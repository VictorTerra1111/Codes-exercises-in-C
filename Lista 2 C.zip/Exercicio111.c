#include <stdio.h>
#include <math.h>
 /*
Título:  Exercicio111.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Escrever um programa que le 3 valores a, b, c que sao lados de um triangulo e calcula e escreve a area deste triangulo. Area = raiz de (s × (s − a) × (s − b) × (s − c)) Onde s = semiperımetro.
Data:  19/03/2024;
  */
int main(){
  double a, b, c, s, area1, raiz;

  printf("\n");
  scanf("%lf %lf %lf", &a, &b, &c);
  s = (a + b + c)/2;
  area1 = s * (s - a) * (s - b) * (s - c);
  raiz = pow(area1, 1/2.0);
  printf("%.4f", raiz);
  return 0;
}