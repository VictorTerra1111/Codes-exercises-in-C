#include <stdio.h>
#include <math.h>
  /*
Título:  Exercicio112.C;
Nome:  João Victor Terra Pereira;
Objetivo:  O custo ao consumidor, de um carro novo, e a soma do custo de fabrica com a percentagem do distribuidor e o percentual dos impostos (aplicados ao custo de fabrica). Escrever um programa que le o custo de fabrica, o percentual do distribuidor e o percentual dos impostos e calcula e escreve o valor a ser pago pelo consumidor por este carro.
Data:  19/03/2024;
  */
int main(){
  double custo_fabrica, per_dis, per_imp, custo_final, valor1, valor2;

  printf("\n");
  scanf("%lf %lf %lf",&custo_fabrica, &per_dis, &per_imp);
  valor1 = (custo_fabrica * per_dis/100);
  valor2 = (custo_fabrica * per_imp/100);
  custo_final = valor1 + valor2 + custo_fabrica;

  printf("%.4f", custo_final);
  return 0;
}