#include <stdio.h>
#include <math.h>
  /*
Título:  Exercicio110.C;
Nome:  João Victor Terra Pereira;
Objetivo: Escrever um programa que le o número de um vendedor, o seu salário fixo, o total de vendas por ele efetuadas e o percentual que ganha sobre o total de suas vendas. Calcular o salario total do vendedor e escrever o número e o salario do vendedor.
Data:  19/03/2024;
  */
int main(){
  int numero;
  double salario_fixo, total_vendas, percentual, calculo;

  printf("\n");
  scanf("%d %lf %lf %lf", &numero, &salario_fixo, &total_vendas, &percentual);
  calculo = salario_fixo + (total_vendas * percentual/100.0);
  printf("%d %.4f", numero, calculo);

  return 0;
}