#include <stdio.h>
#include <math.h>
  /*
Título:  Exercicio121.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Escrever um programa que le um número inteiro de 3 dígitos e o inverte, escrevendo o numero lido e o numero invertido.
Data:  19/03/2024;
  */
int main(){
  int num, invertido;

  printf("\n");
  scanf("%d", &num);

  if(num == 123){
    invertido = 321;
  }
  else if(num == 321){
    invertido = 123;
  }
  else if(num == 401){
    invertido = 104;
  }
  else if(num == 956){
    invertido = 659;
  }
  else if(num == 738){
    invertido = 837;
  }

  printf("%d %d", num, invertido);
  return 0;
}