#include <stdio.h>
#include <math.h>
  /*
Título:  Exercicio120.C;
Nome:  João Victor Terra Pereira;
Objetivo:  O mesmo problema anterior, mas escrevendo o tempo do jogo em minutos.
Data:  19/03/2024;
  */
int main(){
  int horai, horaf, horas;

  printf("\n");
  scanf("%d %d", &horai, &horaf);

  horas =  (horaf - horai) * 60;
  printf("%d", horas);
  return 0;
}