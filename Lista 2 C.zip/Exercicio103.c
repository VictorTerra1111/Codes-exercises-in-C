#include <stdio.h>
#include <math.h>
  /*
Título:  Exercicio103.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Fatorial de 5;
Data:  19/03/2024;
  */
int main(){
  int a;
  a = 5*4*3*2;
  printf("%d", a);
  return 0;
}