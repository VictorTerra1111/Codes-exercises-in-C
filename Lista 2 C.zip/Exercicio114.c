#include <stdio.h>
#include <math.h>
  /*
Título:  Exercicio114.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Considerando que o aumento dos funcionarios de uma empresa tenha sido definido da seguinte forma: 80% de um ındice percentual chamado INTEMP e mais um percentual de produtividade discutido com a empresa por ocasiao do dissıdio da categoria. Escrever um programa que le o numero do funcionario, seu salario atual, o valor percentual do INTEMP e o ındice de produtividade conquistado e escreve o numero do funcionario, seu aumento e seu novo salario.
Data:  19/03/2024;
  */

int main(){
  int num;
  double sal_atual, INTEMP, indProd, n_sal, porcentagem_INTEMP, aumento;

  printf("\n");
  scanf("%d %lf %lf %lf", &num, &sal_atual, &INTEMP, &indProd);

  porcentagem_INTEMP = ((INTEMP * 0.8)/100) * sal_atual;
  n_sal = porcentagem_INTEMP + (sal_atual * indProd/100) + sal_atual;
  aumento = n_sal - sal_atual;
  printf("%d\n%.4f\n%.4f", num, aumento, n_sal);
  return 0;
}