#include <stdio.h>
#include <math.h>
 /*
Título:  Exercicio104.C;
Nome:  João Victor Terra Pereira;
Objetivo: Escrever um programa que le 3 valores reais a, b, c e calcula:
  • A área do triângulo que tem a por base e b por altura;
  • A área do circulo de raio c;
  • A área do trapézio que tem a e b por bases e c por altura;
  • A área do quadrado de lado b;
  • A área do retângulo de lados a e b;
  • A área da superfıcie de um cubo que tem c por aresta.
Data:  19/03/2024;
  */
int main(){
  double a, b, c, atri, acir, atrap, aquad, aret, asupcubo; 
  printf("\n");
  scanf("%lf %lf %lf", &a, &b, &c);
  atri = (a * b) / 2;
  acir = 3.141592*pow(c,2);
  atrap = ((a + b)*c) / 2;
  aquad = b*b;
  aret = a*b;
  asupcubo = (pow(c, 2))*6;
  printf("%.4f %.4f %.4f %.4f %.4f %.4f", atri, acir, atrap, aquad, aret, asupcubo);
  return 0;
}