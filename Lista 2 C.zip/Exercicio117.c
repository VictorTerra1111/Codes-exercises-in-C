#include <stdio.h>
#include <math.h>
/*
Título:  Exercicio117.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Escrever um programa que le o valor de uma compra em dolares e a taxa do dolar no dia da compra e calcula e escreve o valor a ser pago em reais.
Data:  19/03/2024;
  */
int main(){
  double compra, taxa, final;

  printf("\n");
  scanf("%lf %lf", &compra, &taxa);

  final = taxa * compra;
  printf("%.4f", final);
  return 0;
}