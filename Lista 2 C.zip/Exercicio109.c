#include <stdio.h>
#include <math.h> 
  /*
Título:  Exercicio109.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Uma farmacia paga o seu funcionario a cada sexta-feira e deseja deixar pronto o envelope de pagamento. Escrever um programa que lê o valor inteiro do salário do funcionario e calcula qual o menor numero possıvel de notas de 100, 50, 10, 5 e 1, em que o valor lido pode ser decomposto. Escrever o valor lido e o numero de notas de cada tipo que compoe o envelope de pagamento;
Data:  19/03/2024;
  */
int main(){
  int sal, ced_100, resto_100, ced_50, resto_50, ced_10, resto_10, ced_5, resto_5, ced_1, resto_1;

  printf("\n");
  scanf("%d",&sal);
  ced_100 = sal / 100;
  resto_100 = sal % 100;
  ced_50 = resto_100 / 50;
  resto_50 = resto_100 % 50;
  ced_10 = resto_50 / 10;
  resto_10 = resto_50 % 10;
  ced_5 = resto_10 / 5;
  resto_5 = resto_10 % 5;
  ced_1 = resto_5 / 1;
  resto_1 = resto_5 % 1;

  if (ced_100 == 0 && ced_50 == 0 && ced_10 == 0 && ced_5 == 0 && ced_1 != 0){
    printf("%d %d", sal, ced_1);
  }
  else if (ced_100 == 0 && ced_50 == 0 && ced_10 == 0 && ced_5 != 0 && ced_1 != 0){
    printf("%d %d %d", sal, ced_5, ced_1);
  }
  else if (ced_100 == 0 && ced_50 == 0 && ced_10 != 0 && ced_5 != 0 && ced_1 != 0){
    printf("%d %d %d %d", sal, ced_10, ced_5, ced_1);
  }
  else if (ced_100 == 0 && ced_50 != 0 && ced_10 != 0 && ced_5 != 0 && ced_1 != 0){
    printf("%d %d %d %d %d", sal, ced_50, ced_10, ced_5, ced_1);
  }
  else if (ced_100 != 0 && ced_50 != 0 && ced_10 != 0 && ced_5 != 0 && ced_1 != 0){
    printf("%d %d %d %d %d %d", sal, ced_100, ced_50, ced_10, ced_5, ced_1);
  }
  return 0;
}