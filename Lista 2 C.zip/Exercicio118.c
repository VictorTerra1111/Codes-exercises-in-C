#include <stdio.h>
#include <math.h>
/*
Título:  Exercicio118.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Um hotel com 42 apartamentos resolveu fazer promoções para os fins de semana fora da alta temporada, isto é, nos meses de abril, maio, junho, agosto, setembro, outubro e novembro. A taxa da promoção é de 22% da diaria normal. A expectativa é aumentar a taxa de ocupação de 40% para 70%. Supondo que as expectativas se confirmem, escrever um programa que le a diária normal e calcula e escreve as seguintes informações:
  a) O valor da diaria no período da promoção;
  b) O valor medio arrecadado sem a promoção, durante um mês (considere, para simplificar, que todos os meses tem 30 dias).
  c) O valor medio arrecadado com a promoção, durante um mês (mais uma vez, para simplificar, considere que todos os meses tem 30 dias). 
  d) O lucro ou prejuízo mensal com a promoção.
Data:  19/03/2024;
  */
int main(){
  double diaria, diariaPromo, arrecSP, arrecCP, lucro;
  // 40% de 42 = 16.8
  // 70% de 42 = 29.4

  printf("\n");
  scanf("%lf", &diaria);

  diariaPromo = diaria - (diaria * 0.22);
  arrecSP = (diaria * 16.8) * 30;
  arrecCP = (diariaPromo * 29.4) * 30;
  lucro = arrecCP - arrecSP;

  printf("%.4f %.4f %.4f %.4f", diariaPromo, arrecSP, arrecCP, lucro);
  return 0;
}