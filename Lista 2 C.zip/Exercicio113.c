#include <stdio.h>
#include <math.h>
  /*
Título:  Exercicio113.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Uma revendedora de carros usados paga a seus funcionarios vendedores, um salario fixo por mes, mais uma comissao tambem fixa para cada carro vendido e mais 5% do valor das vendas por ele efetuadas. Escrever um programa que le o numero do vendedor, o numero de carros por ele vendidos, o valor de cada carro, o salario fixo e o valor que recebe por carro vendido e calcula o salario a ser pago a este vendedor, escrevendo o numero do vendedor e seu salario total. 
Data:  19/03/2024;
  */
int main(){
  double sal_fixo, valCarro, comCarro, salario_final, salario_carros, sal_vendas;
  int num, numCarros;

  printf("\n");
  scanf("%d", &num);
  printf("\n");
  scanf("%d", &numCarros);
  printf("\n");
  scanf("%lf", &valCarro);
  printf("\n");
  scanf("%lf", &sal_fixo);
  printf("\n");
  scanf("%lf", &comCarro);

  sal_vendas = (valCarro * numCarros) * 0.05;
  salario_carros = comCarro * numCarros;
  salario_final = sal_fixo + salario_carros + sal_vendas;

  printf("%d %.4f", num, salario_final);
  return 0;
}