#include <stdio.h>
#include <math.h>
/*
Título:  Exercicio116.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Escrever um programa que le 3 valores a, b, c e os escreve. Encontre, a seguir, o maior dos 3 valores e o escreva com a mensagem: “E O MAIOR” (sem acento).
Data:  19/03/2024;
  */
int main(){
  double a, b, c, maior;

  printf("\n");
  scanf("%lf %lf %lf", &a, &b, &c);

  if (a > b && a > c){
    maior = a;
    printf("%.4f E O MAIOR", maior);
  }
  else if(b > a && b > c){
    maior = b;
    printf("%.4f E O MAIOR", maior);
  }
  else if(c > a && c > b){
    maior = c;
    printf("%.4f E O MAIOR", maior);
  }
  else if(a == b && b == c){
      maior = a;
      printf("%.4f E O MAIOR", maior);
  }
  return 0;
}