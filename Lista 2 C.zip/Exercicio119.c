#include <stdio.h>
#include <math.h>
  /*
Título:  Exercicio119.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Escrever um programa que le a hora de inicio de um jogo e a hora de fim do jogo, considerando apenas horas inteiras e jogos que começam e terminam no mesmo dia, calcular e escrever o tempo de duração do jogo em horas. 
Data:  19/03/2024;
  */
int main(){
  int horai, horaf, horas;

  printf("\n");
  scanf("%d %d", &horai, &horaf);

  horas =  horaf - horai;
  printf("%d", horas);
  return 0;
}