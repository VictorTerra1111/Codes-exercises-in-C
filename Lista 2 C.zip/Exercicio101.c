#include <stdio.h>
#include <math.h>
  /* 
Título:  Exercicio101.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Escrever um programa que calcula diversos tipos de media, conforme o algoritmo apresentado no início do Capítulo II do livro “Algoritmos e Programação” (aritmética, harmônica, geométrica, ponderada);
Data:  19/03/2024;
  */
int main() {
  double a, b, c, ma, mh, mg, mp;
  scanf("%lf", &a);
  scanf("%lf", &b);
  scanf("%lf", &c);
  ma = (a + b + c) / 3;
  mh = 3/ (1/a + 1/b + 1/c);
  mg = pow((a*b*c), 1.0/3);
  mp = (a + (2.0*b) + (3.0*c)) / 6;
  printf("%.4f %.4f %.4f %.4f", ma, mh, mg, mp);   
  return 0; 
}