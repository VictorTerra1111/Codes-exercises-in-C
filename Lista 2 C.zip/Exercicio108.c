#include <stdio.h>
#include <math.h>
 /*
Título:  Exercicio108.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Um avião em linha reta, a uma altitude a passa sobre um ponto p situado no solo, num instante t = 0. Se a velocidade é v, calcular a distancia d do aviao ao ponto p apos 30 segundos. Escrever um programa que le v (em m/s) e a (em m) e calcula e escreve a distancia do avião ao ponto p apos 30 segundos.
Data:  19/03/2024;
  */
int main(){
  double v, a, posicao, distancia;
  // v = velocidade
  // a = altitude

  printf("\n");
  scanf("%lf %lf", &v, &a);
  posicao = v * 30;
  distancia = pow((pow(posicao, 2) + pow(a, 2)), 1/2.0);
  printf("%.4f", distancia);

  return 0;
}