#include <stdio.h>
#include <math.h>
 /* 
Título:  Exercicio102.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Escrever um programa que le o numero de um funcionario (inteiro), seu numero de horas trabalhadas(real), o valor que recebe por hora (real), o numero de filhos com idade menor do que 14 anos (inteiro) e o valor do salario famılia (pago por filho com menos de 14 anos; real). Calcular o salario total deste funcionario e escrever o seu numero e o seu salario total;
Data:  19/03/2024;
  */
int main(){
  int num_func, num_filhos; 
  double horas, valor_hora, salario_familia, sal_total, salario, sal_dos_filhos;

  scanf("%d %lf %lf %d %lf", &num_func, &horas, &valor_hora, &num_filhos, &salario_familia);

  salario = horas * valor_hora;
  sal_dos_filhos = num_filhos * salario_familia;
  sal_total = salario + sal_dos_filhos;
  printf("%d %.4f", num_func, sal_total);

  return 0;
}