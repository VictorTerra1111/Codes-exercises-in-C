#include <stdio.h>
#include <math.h>
  /*
Título:  Exercicio115.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Escrever um programa que le as coordenadas de dois pontos no plano cartesiano e calcula e escreve a distancia entre estes dois pontos, sabendo-se que a formula da distancia entre dois pontos P1(X1, Y1) e P2(X2, Y2) e Distancia = raiz de ((X2 − X1)² + (Y2 − Y1)²).
Data:  19/03/2024;
  */
int main(){
  double x1, x2, y1, y2, calculo, raiz_final;

  printf("\n");
  scanf("%lf %lf %lf %lf", &x1, &y1, &x2, &y2);
  calculo = pow((x2 - x1), 2) + pow((y2 - y1), 2);
  raiz_final = pow(calculo, 1/2.0);

  printf("%.4f", raiz_final);
  return 0;
}