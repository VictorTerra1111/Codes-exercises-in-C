#include <stdio.h>
#include <math.h>
 /*
Título:  Exercicio107.C;
Nome:  João Victor Terra Pereira;
Objetivo:  Escrever um programa que lê o número de peças do tipo 1, o valor de cada peça do tipo 1, o número de peças do tipo 2, o valor de cada peça do tipo 2 e o percentual do IPI a ser acrescentado. Calcular e escrever o valor total a ser pago por esta compra.
Data:  19/03/2024;
  */
int main(){
  int num_p1, num_p2;
  double valor_p1, valor_p2, IPI, valortotal1, valortotal2, soma, valor_final;

  printf("\n");
  scanf("%d %lf", &num_p1, &valor_p1);
  // num_p1 = valor_p1 (numero de peças 1 vale o valor p1)
  printf("\n");
  scanf("%d %lf", &num_p2, &valor_p2);
  // num_p2 = valor_p2 (numero de peças 2 vale o valor p2)
  printf("\n");
  scanf("%lf", &IPI);

  valortotal1 = num_p1 * valor_p1;
  valortotal2 = num_p2 * valor_p2;
  soma = valortotal1 + valortotal2;
  valor_final = (soma * IPI/100) + soma;
  printf("%.4f", valor_final);
  return 0;
}