#include <stdio.h>
/* 
Autor: João Victor Terra Pereira; 
Data: 06/06/2024;
Objetivo:  Uma pequena loja de artesanato possui apenas um vendedor e comercializa dez tipos de objetos. O vendedor recebe, mensalmente, salario de R$545,00, acrescido de 5% do valor total de suas vendas. O valor unitario dos objetos deve ser informado e armazenado em um vetor; a quantidade vendida de cada peça deve ficar em outro vetor, mas na mesma posiçao. Crie um programa que receba os preços e as quantidades vendidas, armazenando-os em seus respectivos vetores (ambos com tamanho dez). Depois, determine e mostre:
  • um relatorio contendo: quantidade vendida, valor unitario e valor total de cada objeto. Ao final, deverao ser mostrados o valor geral das vendas e o valor da comissao que ser a paga ao vendedor;
  • o valor do objeto mais vendido e sua posiçao no vetor (em caso de empate mostre estas informaçoes para todos os objetos).
*/

int main(){
  int quant[10], vendas = 0, posicao_obj = 0;
  double precos[10], valores[10], valor_total = 0.0, salario, objmais[10];

  for(int i = 0; i < 10; i++){
    scanf("%lf %d", &precos[i], &quant[i]); // leitura
  }

  for(int i = 0; i < 10; i++){
    valores[i] = quant[i] * precos[i]; // preço total da quantidade x preço de cada uma;
  }

  for(int i = 0; i < 10; i++){
    valor_total = valor_total + valores[i]; // soma do valor total de todas as vendas
  }
  // salario de R$545,00, acrescido de 5% do valor total de suas vendas
  double comissao = valor_total * 0.05;
  salario = 545.00 + comissao;

  // calcula o mais vendido e a posicao
  int max_quant, max_count, max_posicoes[10];

  for (int i = 0; i < 10; i++) {
      if (quant[i] > max_quant) {
          max_quant = quant[i];
          max_count = 1;
          max_posicoes[0] = i;
      } else if (quant[i] == max_quant) {
          max_posicoes[max_count] = i;
          max_count++;
      }
  }

  for(int i = 0; i < 10; i++){
    printf("%d %.4lf %.4lf\n", quant[i], precos[i], valores[i]); // impressao da primeira parte
  }
  printf("%.4lf %.4lf\n", valor_total, comissao);

  for(int i = 0; i<10; i++){
    printf("%.4lf %d\n", precos[max_posicoes[i]], max_posicoes[i]);
  }

  return 0;
}
