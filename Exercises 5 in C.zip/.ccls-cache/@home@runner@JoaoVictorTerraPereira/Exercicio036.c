#include <stdio.h>
  /* 
Autor: João Victor Terra Pereira; 
Data: 06/06/2024;
Objetivo: Faca um programa que receba dez numeros inteiros e armazene-os em um vetor. Calcule e mostre dois vetores resultantes: o primeiro com os numeros pares e o segundo com os numeros ımpares.
  */
int main(){
  int vet[10], pares[10], impares[10];
  int par = 0, impar = 0;

  for(int i = 0; i < 10; i++){ // reading
    scanf("%d", &vet[i]);
  }

  for(int i = 0; i< 10; i++){
    if(vet[i] % 2 == 0){
      pares[par++] = vet[i]; // test if even
    }
    else {
      impares[impar++] = vet[i]; // if not even, must be odd
    }
  }


  if(par > 0){
    for(int i = 0; i < par; i++){ // print the even
      printf("%d ", pares[i]);
    }
  }

  printf("\n");

  if(impar > 0){
      for(int i = 0; i < impar; i++){
        printf("%d ", impares[i]); // print the odd
      }
  }
  return 0;
}