#include <stdio.h>
  /* 
Autor: João Victor Terra Pereira; 
Data: 06/06/2024;
Objetivo: Faca um programa que leia dois vetores A e B com cinco posicoes para numeros inteiros. O programa deve, entao,
subtrair o primeiro elemento de A do ultimo de B, acumulando o valor, subtraindo o segundo elemento de A do penultimo de B, acumulando o valor e assim por diante. Ao final mostre o resultado de todas as subtracoes realizadas.
  */
int main(){
  int A[5], B[5], position, C[5];

  for(int i = 0; i < 5; i++){
    scanf("%d", &A[i]); // read the values for A--- OK
  }

  for(int i = 0; i < 5; i++){
    scanf("%d", &B[i]); // read the values for B--- OK
  }

  for(int i = 0; i < 5; i++){
    position = (i + 4) - (i * 2); // calculate the equations
    C[i] =  B[position] - A[i];
  }

  printf("\n");

  for(int i = 0; i < 5; i++){
    printf("%d ", C[i]);
  }


  return 0;
}