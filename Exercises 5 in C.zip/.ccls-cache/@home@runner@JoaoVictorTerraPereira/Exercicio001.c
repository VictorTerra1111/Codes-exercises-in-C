#include <stdio.h>
  /* 
  Autor: João Victor Terra Pereira; 
  Data: 06/06/2024;
  Objetivo:  Faça um programa que leia um vetor com nove números inteiros, calcule e mostre os numeros primos e suas respectivas posicoes 
  */


int primos(int valor){
  if(valor <= 1) {return 0;} //se for menor que 2 não será primo

  for (int i = 2; i <= valor / 2; i++){ 
    if (valor % i == 0) {return 0;} // verifica se não é primo
  }

  return 1; // se for primo retorna 1
}

int main(){
  int vet[9];
  int posicao[9];
  int contagem = 0;
  int vetprim[9];

  for(int i = 0; i < 9; i++){ // leitura 
    scanf("%d", &vet[i]);
  }

  for(int i = 0; i < 9; i++){
    if(primos(vet[i]) != 0){
      posicao[contagem] = i;
      vetprim[contagem] = vet[i];
      contagem++;
    }
  }

  for(int i = 0; i < contagem; i++){ // impressao
    printf("%d %d\n",  vetprim[i], posicao[i]);
  }
  return 0;
}


