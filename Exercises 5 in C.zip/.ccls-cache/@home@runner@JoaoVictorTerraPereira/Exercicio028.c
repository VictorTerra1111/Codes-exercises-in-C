#include <stdio.h>
#define MAX 10
  /* 
Autor: João Victor Terra Pereira; 
Data: 06/06/2024;
Objetivo:  
  Faca um programa para controlar o estoque de mercadorias de uma empresa. Inicialmente, o programa devera preencher dois vetores com dez posicoes cada, onde o primeiro corresponde ao codigo do produto (valor inteiro) e o segundo, a quantidade total desse produto em estoque (valor inteiro). A leitura deve se feita por produto, ou seja, codigo e quantidade para o primeiro produto, codigo e quantidade para o segundo produto e assim por diante.
  Logo apos, o programa devera ler um conjunto indeterminado de dados contendo o codigo de um cliente (valor inteiro) e o codigo do produto que ele deseja comprar (valor inteiro), juntamente com a quantidade (valor inteiro). Codigo do cliente igual a zero indica fim do programa (o que significa que nao se deve tentar fazer a leitura de codigo e quantidade). O programa devera verificar: 

  • se o codigo do produto solicitado existe. Se existir, tentar atender ao pedido; caso contrario, exibir mensagem “PRODUTO INEXISTENTE”;
  
• cada pedido feito por um cliente so pode ser atendido integralmente. Caso isso n ao seja possıvel, escrever a mensagem “SEM ESTOQUE”. Se puder atende-lo, escrever a mensagem “PEDIDO ATENDIDO”;

• efetuar a atualizacao do estoque somente se o pedido for atendido integralmente;

• no final do programa, escrever os codigos dos produtos com seus respectivos estoques ja atualizados.
  */

int main() {
  int codigo[MAX], estoque[MAX];
  int cliente, codigoPedido, quantidadePedido;

  for (int i = 0; i < MAX; i++) {
    scanf("%d %d", &codigo[i], &estoque[i]); // lê o codigo e o estoque incial
  }

  printf("\n");

  while (scanf("%d", &cliente) && cliente != 0) { // le o codigo do cliente e verifica se é diferente de zero
    scanf("%d %d", &codigoPedido, &quantidadePedido); //le o codigo e a quantidade exigida 
    int encontrou = 0;

    for (int i = 0; i < MAX; i++) {
      if (codigo[i] == codigoPedido) { // se existe
        encontrou = 1;
        if (estoque[i] >= quantidadePedido) {
          estoque[i] -= quantidadePedido;
          printf("PEDIDO ATENDIDO\n"); // se existe e tem estoque
        } 
        else {
          printf("SEM ESTOQUE\n"); // se nao atende a quantidade
        }
        break;
      }
    }
    
    if (!encontrou){
      printf("PRODUTO INEXISTENTE\n"); // se nao existe
    }
  }

  for (int i = 0; i < MAX; i++) {
    printf("%d %d\n", codigo[i], estoque[i]); // imprime novo estoque
  }
  return 0;
}

