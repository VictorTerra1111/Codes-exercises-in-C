#include <stdio.h>
/* 
Autor: João Victor Terra Pereira; 
Data: 06/06/2024;
Objetivo:  Faca um programa que leia um vetor com oito numeros inteiros, calcule e mostre dois vetores resultantes. O primeiro vetor resultante deve conter os numeros positivos e o segundo, os numeros negativos. Cada vetor resultante vai ter, no maximo, oito posicoes, que nao poderao ser completamente utilizadas. Considere que zero nao e nem positivo, nem negativo. Podem nao haver valores positivos ou negativos no vetor original, neste caso deve-se imprimir uma linha vazia na saıda.
*/
int main(){
  int vet[8], mais[8], menos[8], pos = 0, neg = 0;

  for(int i = 0; i<8; i++){ // leitura do vetor
    scanf("%d", &vet[i]);
  }

  for(int i = 0; i<8; i++){

    if(vet[i] > 0){ // calcula quais são positivos
      mais[pos++] = vet[i];
    }   

    else if(vet[i] < 0){ // calcula os negativos
      menos[neg++] = vet[i];
    } 
  }

  if (pos > 0){
    for(int i = 0; i< pos; i++){ // impressao
      printf("%d ", mais[i]); 
    }
  }

  printf("\n");

  if (neg > 0){
    for(int i = 0; i< neg; i++){ // impressao
    printf("%d ", menos[i]); 
    }
  }
  return 0;
}
