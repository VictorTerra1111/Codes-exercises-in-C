#include <stdio.h>
/* 
Autor: João Victor Terra Pereira; 
Data: 06/06/2024;
Objetivo:  Faca um programa que leia um vetor com seis elementos numericos inteiros. Calcule e mostre, nessa ordem:
• a quantidade de numeros pares;
• todos os numeros pares (se houver numeros pares); 
• a quantidade de numeros ımpares;
• todos os numeros ımpares (se houver numeros ımpares).
*/


int main(){
 int vet[6], quant_par = 0, pares[6], quant_im = 0, impares[6];

  for(int i = 0; i < 6; i++){
    scanf("%d", &vet[i]); // leitura
  }

  for(int i = 0; i < 6; i++){
    if(vet [i] % 2 == 0){
      pares[quant_par++] = vet[i]; // par
    }
    else {
      impares[quant_im++] = vet[i]; // impar
    }
  }

  if (quant_par > 0){

    printf("%d \n", quant_par);

    for(int i = 0; i < quant_par; i++){ // impressao par
      printf("%d ", pares[i]);
    }
  }

  printf("\n");

  if (quant_im > 0){

    printf("%d\n", quant_im);

    for(int i = 0; i < quant_im; i++){ //impressao impar
      printf("%d ", impares[i]);
    }
  }

  return 0;
}