#include <stdio.h>
  /* 
Autor: João Victor Terra Pereira; 
Data: 06/06/2024;
Objetivo:  Faca um programa que preencha um vetor com quinze elementos inteiros (lidos do terminal) e verifique a existencia de elementos iguais a 30, mostrando as posicoes em que apareceram.
  */
int main(){
  int vet[15], trintas = 0, posicao[15];

  for(int i = 0; i < 15; i++){
    scanf("%d", &vet[i]); // leitura e armazenamento
  }

  for(int i = 0; i < 15; i++){
    if(vet[i] == 30){; // verifica se é trinta e armazena a posicao
      posicao[trintas++] = i;
    }
  }

  if(trintas > 0){
    for(int i = 0; i < trintas; i++){
      printf("%d ", posicao[i]); // impressao
    }
  }
  return 0;
}