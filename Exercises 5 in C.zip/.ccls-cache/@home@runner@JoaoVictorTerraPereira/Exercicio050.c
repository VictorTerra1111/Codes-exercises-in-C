#include <stdio.h>
  /* 
Autor: João Victor Terra Pereira; 
Data: 06/06/2024;
Objetivo: Faca um programa que leia um vetor com quinze posicoes para numeros inteiros. Depois da leitura, divida todos os seus elementos pelo maior valor do vetor. Mostre o vetor apos os calculos.
  */
int main(){
  double vet[15], big = 0;
  double array[15];

  for(int i = 0; i < 15; i++){
    scanf("%lf", &vet[i]); // reading
  }

  big = vet[0];

  for(int i = 1; i < 15; i++){
    if(big < vet[i]){ // finding the biggest number 
      big = vet[i];
    }
  }

  for(int i = 0; i< 15; i++){
    array[i] = vet[i] / big; // diving
  }
  for(int i = 0; i < 15; i++){
    printf("%.4lf ", array[i]); // printing
  }

  return 0;
}
