#include <stdio.h>
#include <string.h>

  /* 
Autor: João Victor Terra Pereira; 
Data: 06/06/2024;
Objetivo: Uma escola deseja saber se existem alunos cursando, simultaneamente, as disciplinas Logica e Linguagem de Programacao. Coloque os numeros das matrıculas dos alunos que cursam Logica em um vetor, quinze alunos. Coloque os numeros das matrıculas dos alunos que cursam Linguagem de Programacao em outro vetor, dez alunos. Mostre o numero das matrıculas que aparecem nos dois vetores, na ordem em que aparecem na lista de alunos que cursam Logica. Considere que os numeros de matrıcula sejam cadeias de caracteres sem espacos.
  */
int main() {
    char logica[15][7];
    char lingua[10][7];
    char iguais[10][7];

  for (int i = 0; i < 15; i++) {
    scanf("%s", logica[i]); // reading logics
    logica[i][strcspn(logica[i], "\n")] = '\0'; 
  }
  for (int i = 0; i < 10; i++) {
    scanf("%s", lingua[i]); // reading language
    lingua[i][strcspn(lingua[i], "\n")] = '\0'; 
  }

  printf("\n");

  for (int i = 0; i < 15; i++) {
      for (int j = 0; j < 10; j++) {
          if (strcmp(logica[i], lingua[j]) == 0) {
              printf("%s\n", logica[i]);
          }
      }
  }

    return 0;
}
