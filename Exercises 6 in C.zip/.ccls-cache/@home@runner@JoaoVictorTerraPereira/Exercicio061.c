#include <stdio.h>

  /* 
Autor: João Victor Terra Pereira
Data: 11/06/2024
Objetivo: Crie um programa que leia do terminal uma matriz 8 × 8 com numeros inteiros e mostre uma mensagem dizendo se a matriz digitada e simetrica (imprima o texto “Matriz Simetrica” - assim, sem acentos). Uma matriz so pode ser considerada simetrica se Aij = Aji. Caso a matriz nao seja simetrica, seu programa devera imprimir “Matriz Assimetrica” (assim, sem acentos).
  */

int main(){
  int matriz[8][8];

  for(int i = 0; i < 8; i++){
    for(int j =  0; j < 8; j++){
      scanf("%d", &matriz[i][j]); // le os valores para a matriz
    }
  }
  int simetrica = 1; // flag para verificar se é simetrica 

  for(int i = 0; i < 8; i++){
    for(int j = 0; j < 8; j++){
      int Aij = matriz[i][j]; // salva o valor em uma variavel temporária
      int Aji = matriz[j][i]; // salvo o valor da posicao inversa em outra variavel
      if(Aij != Aji){
        simetrica = 0; // se forem diferentes atribui 0 a flag
      }
    }
  }

  if(simetrica) {printf("Matriz Simetrica");} // impressao se se manter 1
  else { printf("Matriz Assimetrica");} // impressao se retornar 0

  return 0;
}