#include <stdio.h>
  /* 
Autor: João Victor Terra Pereira
Data: 11/06/2024
Objetivo: Elabore um programa que leia do terminal uma matriz 4 × 4 com numeros inteiros e verifique se essa matriz forma o chamado quadrado magico. Um quadrado magico e formado quando a soma dos elementos de cada linha e igual a soma dos elementos de cada coluna dessa linha, e igual a soma dos elementos da diagonal principal e, tambem, e igual a soma dos elementos da diagonal secundaria. Caso a matriz forme um quadrado magico, seu programa deve imprimir “ Forma quadrado magico” (assim, sem acentos). E caso nao forme, deve imprimir “Nao forma quadrado magico” (tambem sem acentos).
  */

int main(){
  int matriz[4][4];
  int soma = 0; // variavel inicializada em zero para soma
  int col, dia, seg, linhas;

  for(int i = 0; i < 4; i++){
    for(int j = 0; j < 4; j++){
      scanf("%d", &matriz[i][j]); //leitura de valores
    }
  }
  int magico = 1; // flag para identificar se é um quadrado magico ou nao

  //descobre a soma da primeira linha e usa de base
  for(int i = 0; i < 4; i++){
      soma += matriz[0][i];
  }
  // descobre o resultado das somas das outras linhas e compara com "soma"
  for(int i = 1; i < 4; i++){
    int soma_linha = 0;
    for(int j = 0; j < 4; j++){
      soma_linha += matriz[i][j];
    }
     if(soma_linha != soma){ magico = 0; break;}
  }
  // descobre o resultado das somas das colunas e compara com "soma"
  for(int i = 0; i < 4; i++){
    int soma_coluna = 0;
    for(int j = 0; j < 4; j++){
     soma_coluna += matriz[j][i];
    }
     if(soma_coluna != soma){ magico = 0; break;}
  }
  printf("\n");
  // descobre o valor da soma da diagonal principal e da diagonal secundaria e compara com "soma"
  int soma_diag = 0;
  int soma_sec = 0;
  for(int i = 0; i < 4; i++){
    for(int j = 0; j < 4; j++){
      if(i == j){ soma_diag += matriz[i][j];}
      else if (i+j == 3){ soma_sec += matriz[i][j];}
      else{continue;}
    }
  }
  if(soma_diag != soma || soma_sec != soma){ // atualiza a flag caso a soma seja diferente 
    magico = 0;
  }

  if (magico) {printf("Forma quadrado magico");} //imprime caso a flag nao tenha sido alterada
  else {printf("Nao forma quadrado magico");} // imprime caso a flag tenha sido alterada

  return 0;
}