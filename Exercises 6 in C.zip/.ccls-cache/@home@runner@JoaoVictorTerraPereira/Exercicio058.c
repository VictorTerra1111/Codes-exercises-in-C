#include <stdio.h>

  /* 
Autor: João Victor Terra Pereira
Data: 11/06/2024
Objetivo:Elabore um programa que preencha uma matriz 6 × 4 com numeros inteiros, calcule e mostre quantos elementos dessa matriz sao maiores que 30 e, em seguida, monte e imprima uma segunda matriz com os elementos diferentes de 30. No lugar do numero 30, da segunda matriz, coloque o numero zero.
  */

int main(){
  int matrix[6][4];
  for(int i = 0; i < 6; i++){
    for(int j = 0; j < 4; j++){ 
      scanf("%d", &matrix[i][j]); // lê os valores para a matriz
    }
  }

  int maiores = 0;
  for(int i = 0; i < 6; i++){ 
    for(int j = 0; j < 4; j++){
      if(matrix[i][j] > 30){ // procura quais são maiores que 30 e adiciona a contagem 'maiores'
        maiores++;
      }
    }
  }

  for(int i = 0; i < 6; i++){ 
    for(int j = 0; j < 4; j++){
      if(matrix[i][j] == 30) {matrix[i][j] = 0;} // procura os elementos iguais a 30 e troca por 0
    }
  }
  printf("%d\n\n", maiores);
  for(int i = 0; i < 6; i++){
    for(int j = 0; j < 4; j++){ 
      printf("%d ", matrix[i][j]); // imprime a matriz atualizada
    }
    printf("\n");
  }

  return 0;
}