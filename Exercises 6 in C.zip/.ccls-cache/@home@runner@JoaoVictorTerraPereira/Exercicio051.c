#include <stdio.h>

  /* 
  Autor: João Victor Terra Pereira
  Data: 11/06/2024
  Objetivo: Na teoria dos sistemas, define-se o elemento MINMAX de uma matriz como o maior elemento da linha em que se encontra o menor elemento da matriz. Elabore um programa que carregue uma matriz 4 × 7 com numeros reais, calcule e mostre seu MINMAX e sua posicao (linha e coluna). Em caso de empate (dois elementos com menor valor ou maior valor), considere a primeira ocorrencia.  
  */

int main(){
  double matriz[4][7];
  double MINMAX;
  int coluna_min, linha, coluna;

  for(int i = 0; i < 4; i++){
    for(int j =0; j < 7; j++){
      scanf("%lf", &matriz[i][j]); // lê os valores para a matriz
    }
  }

  double menor = matriz[0][0]; // seta o menor sendo o primeiro elemento da matriz
  for(int i = 0; i < 4; i++){
    for(int j=0;j<7;j++){
      if(menor > matriz[i][j]){ menor = matriz[i][j]; linha = i; coluna_min = j;}  // itera por cada linha e coluna até achar o menor e atualiza o valor salvando a linha e a coluna
    }
  }

  MINMAX = matriz[linha][coluna_min]; //seta o MINMAX sendo o menor valor do vetor

  for(int i = 0; i < 7; i++){
    if (MINMAX < matriz[linha][i]){ 
      MINMAX = matriz[linha][i]; // itera por cada item do vetor até achar o maior valor e atualiza o valor
      coluna = i; // salva a posição no vetor
    }
  }
  printf("%.4lf %d %d", MINMAX, linha, coluna); // imprime o resultado final

  return 0;
}