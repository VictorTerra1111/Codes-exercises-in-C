#include <stdio.h>

  /* 
Autor: João Victor Terra Pereira
Data: 11/06/2024
Objetivo: Faca um programa que leia do terminal uma matriz 7×7 de numeros inteiros e crie dois vetores com sete posicoes cada um que contenham, respectivamente, o maior elemento de cada uma das linhas e o menor elemento de cada uma das colunas. Escreva a matriz e os dois vetores gerados.
  */

int main(){
  int matriz[7][7], v1[7], v2[7];

  for(int i = 0;i < 7; i++){
    for(int j = 0; j < 7; j++){
      scanf("%d", &matriz[i][j]); // le os elementos para a matriz
    }
  }

  for(int i = 0;i < 7; i++){
    int maior = matriz[i][0]; // assume que o primeiro valor do vetor é o maior

    for(int j = 1;j < 7; j++){
      if (matriz[i][j] > maior){
        maior = matriz[i][j]; // itera sobre cada valor e descobre se é maior que o armazenado
      }
    }
    v1[i] = maior; // adiciona o maior valor no indice do vetor v1
  }
  int menor;

  for(int i = 0;i < 7; i++){
    menor = matriz[0][i];
    for(int j = 0; j < 7; j++){
      if(menor > matriz[j][i]){ menor = matriz[j][i];}
    }
    v2[i] = menor; // adiciona o menor valor na coluna  
  }
  printf("\n");
  for(int i = 0;i < 7; i++){
    for(int j = 0; j < 7; j++){
      printf("%d ", matriz[i][j]); // imprime a matriz
    }
    printf("\n");
  }
printf("\n");
  for(int i = 0; i < 7; i++){ printf("%d ", v1[i]);}
  printf("\n\n");
  for(int i = 0; i < 7; i++){ printf("%d ", v2[i]);}

  return 0;
}

